 ///
 /// @file    Threadpool.cc
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-11 11:13:40
 ///
#include "Threadpool.h"
#include "Thread.h"
#include <unistd.h>
#include <iostream>

using std::cout;
using std::endl;
Threadpool::Threadpool(size_t buffsize,size_t threadnum)
:_buffsize(buffsize)
,_threadNum(threadnum)
,_buffer(_buffsize)
,_isExit(false)
{}
Threadpool::~Threadpool()
{
	if(!_isExit)
		stop();
}
void Threadpool::start()
{
	for(size_t idx=0;idx!=_threadNum;++idx)
	{
		shared_ptr<Thread> pth(new Thread(std::bind(&Threadpool::threadFunc,this)));
		_threads.push_back(pth);
		pth->start();
	}
}
void Threadpool::stop()
{
	cout<<"Threadpool::stop()"<<endl;
	if(!_isExit)
	{
		while(!_buffer.empty())
		{
			sleep(1);
		}
		_isExit=true;
		_buffer.wakeup();
		
		for(auto &elem:_threads)
			elem->join();
	}
}
void Threadpool::addTask(Task task)
{
	_buffer.push(task);
}
Threadpool::Task Threadpool::getTask()
{
	return _buffer.pop();
}
void Threadpool::threadFunc()
{
	while(!_isExit)
	{
		Task task=getTask();
		if(task)
			task();
	}
}
