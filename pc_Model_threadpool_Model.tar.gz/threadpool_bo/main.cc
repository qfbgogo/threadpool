 ///
 /// @file    main.cc
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-11 20:47:22
 ///
#include "Threadpool.h"
#include "Buffer.h"
#include "Task.h"
#include <iostream>
#include <functional>
int main()
{
	function<void()> task=std::bind(&Task::execute,Task());
	Threadpool threadpool(10,4);
	threadpool.start();

	size_t cnt=20;
	while(cnt--)
	{
		threadpool.addTask(task);
	}
	threadpool.stop();
	return 0;
}
