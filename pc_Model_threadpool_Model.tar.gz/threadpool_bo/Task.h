 ///
 /// @file    Task.h
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-24 12:10:11
 ///
#ifndef __TASK_H__
#define __TASK_H__
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include <iostream>
using namespace std;
class Task
{
	public:
		void execute()
		{
			srand(time(NULL));
			int number=rand()%100;
			cout<<"produce a number: "<<number<<endl;
			sleep(1);
		}
};
#endif
