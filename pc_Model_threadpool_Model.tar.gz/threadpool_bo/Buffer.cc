 ///
 /// @file    Buffer.cc
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-10 20:36:21
 ///
#include "Buffer.h"
Buffer::Buffer(int size)
:_sz(size)
,_notFull(_mutex)
,_notEmpty(_mutex)
,_flag(true)
{}
bool Buffer::empty()
{
	return _que.size()==0;
}
bool Buffer::full()
{
	return _que.size()==_sz;
}
void Buffer::push(ElemType data)
{
	GuardMutexLock guard_mutex_lock(_mutex);
	while(full())
		_notFull.wait();
	_que.push(data);
	_notEmpty.notify();
}
ElemType Buffer::pop()
{
	GuardMutexLock guard_mutex_lock(_mutex);
	while(_flag&&empty())
		_notEmpty.wait();
	if(_flag)
	{
		ElemType temp=_que.front();
		_que.pop();
		_notFull.notify();
		return temp;
	}else{
		return NULL;
	}
}
void Buffer::wakeup()
{
	_flag=false;
	_notEmpty.notifyall();
}
