 ///
 /// @file    Thread.h
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-09 19:11:10
 ///
#ifndef _THREAD_H_
#define _THREAD_H_
#include "Noncopyable.h"
#include <pthread.h>
#include <functional>
class Thread:private Noncopyable
{
	public:
		typedef std::function<void()> ThreadCallBack;
	public:
		void start();
		void join();
		Thread(ThreadCallBack);
		~Thread();
	private:
		static void *threadFunc(void *);
		pthread_t _threadID;
		bool _isrunning;
		ThreadCallBack _cb;
};
#endif
