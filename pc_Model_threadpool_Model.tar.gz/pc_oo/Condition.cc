 ///
 /// @file    Condition.cc
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-11 09:48:10
 ///
#include "Condition.h"

Condition::Condition(MutexLock &mutex)
:_mutex(mutex)
{
	pthread_cond_init(&_cond,NULL);
}
Condition::~Condition()
{
	pthread_cond_destroy(&_cond);
}
void Condition::notify()
{
	pthread_cond_signal(&_cond);
}
void Condition::notifyall()
{
	pthread_cond_broadcast(&_cond);
}
void Condition::wait()
{
	pthread_cond_wait(&_cond,&_mutex._mutex);
}
