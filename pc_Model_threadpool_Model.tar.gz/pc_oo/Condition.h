 ///
 /// @file    Condition.h
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-10 19:41:05
 ///
#ifndef __CONDITION_H__
#define __CONDITION_H__
#include "MutexLock.h"
#include <pthread.h>
class Condition
{
	public:
		Condition(MutexLock&);
		~Condition();
		void notify();
		void notifyall();
		void wait();
	private:
		MutexLock &_mutex;
		pthread_cond_t _cond;
};
#endif
