 ///
 /// @file    MutexLock.cc
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-04-12 21:47:58
 ///
#ifndef __MUTEXLOCK_H__
#define __MUTEXLOCK_H__
#include <pthread.h> 
#include <unistd.h>
class MutexLock
{
	public:
		MutexLock();
		~MutexLock();
		void lock();
		void unlock();
	public:
		 pthread_mutex_t _mutex;

};
class GuardMutexLock
{
	private:
		MutexLock &_mutex;
	public:
		GuardMutexLock(MutexLock &mutexLock)
		:_mutex(mutexLock)
		{
			_mutex.lock();
		}
		~GuardMutexLock()
		{
			_mutex.unlock();
		}
};
#endif
