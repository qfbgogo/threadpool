 ///
 /// @file    Thread.cc
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-09 19:20:53
 ///
#include "Thread.h"
Thread::Thread():_isrunning(false){}
void Thread::start()
{
	pthread_create(&_threadID,NULL,threadFunc,this);
	if(_threadID)
		_isrunning=true;
}
void *Thread::threadFunc(void *arg)
{
	Thread *pth=static_cast<Thread *> (arg);
	pth->run();
}
void Thread::join()
{
	pthread_join(_threadID,NULL);
	_isrunning=false;
}
Thread::~Thread()
{
	pthread_detach(_threadID);
	_isrunning=false;
}
