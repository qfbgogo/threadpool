 ///
 /// @file    testThread.cc
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-09 19:43:33
 ///
#include "Consumer.h"
#include "Producer.h"
#include <time.h>
#include <unistd.h>
#include <iostream>
int main()
{
	Buffer buffer(10);
	
	Thread *thread_p=new Producer(buffer);
	Thread *thread_c=new Consumer(buffer);
	
	thread_p->start();
	thread_c->start();

	thread_p->join();
	thread_c->join();
	
	return 0;
}
