 ///
 /// @file    Noncopyable.h
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-09 20:24:55
 ///
#ifndef _NONCOPYABLE_H_
#define _NONCOPYABLE_H_
class Noncopyable
{
	protected:
		Noncopyable(){};
		~Noncopyable(){};
	private:
		Noncopyable(const Noncopyable &);
		Noncopyable &operator=(const Noncopyable &);
};
#endif
