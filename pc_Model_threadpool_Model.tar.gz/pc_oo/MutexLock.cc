 ///
 /// @file    MutexLock.cc
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-11 09:50:37
 ///
#include "MutexLock.h"

MutexLock::MutexLock()
{
	pthread_mutex_init(&_mutex,NULL);
}
MutexLock::~MutexLock()
{
	pthread_mutex_destroy(&_mutex);
}
void MutexLock::lock()
{
	pthread_mutex_lock(&_mutex);
}
void MutexLock::unlock()
{
	pthread_mutex_unlock(&_mutex);
}
