 ///
 /// @file    Consumer.h
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-10 20:29:52
 ///
#ifndef __CONSUMER_H__
#define __CONSUMER_H__
#include "Buffer.h"
#include "Thread.h"
#include <unistd.h>
#include <iostream>
using std::endl;
using std::cout;
class Consumer:public Thread
{
	public:
		Consumer(Buffer&);
		void run();
	private:
		Buffer &_buffer;
};
Consumer::Consumer(Buffer &buffer)
:_buffer(buffer)
{}
void Consumer::run()
{
	while(true)
	{
		if(!_buffer.empty())
		{
			cout<<"consumer a number: "<<_buffer.getFront()<<endl;
			_buffer.pop();
			sleep(2);
		}
	}
}
#endif
