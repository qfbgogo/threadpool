 ///
 /// @file    Buffer.cc
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-10 20:36:21
 ///
#include "Buffer.h"
Buffer::Buffer(int size)
:_sz(size)
,_notFull(_mutex)
,_notEmpty(_mutex)
{}
bool Buffer::empty()
{
	return _que.size()==0;
}
bool Buffer::full()
{
	return _que.size()==_sz;
}
void Buffer::push(ElemType data)
{
	GuardMutexLock guard_mutex_lock(_mutex);	
	while(full())
		_notFull.wait();
	_que.push(data);
	_notEmpty.notify();
}
void Buffer::pop()
{
	GuardMutexLock guard_mutex_lock(_mutex);
	while(empty())
		_notEmpty.wait();
	ElemType temp=_que.front();
	_que.pop();
	_notFull.notify();
}
ElemType Buffer::getFront()
{
	return _que.front();
}
