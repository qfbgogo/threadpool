 ///
 /// @file    Producer.h
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-10 20:12:50
 ///
#ifndef __PRODUCER_H__
#define __PRODUCER_H__
#include "Buffer.h"
#include "Thread.h"
#include <unistd.h>
#include <time.h>
#include <iostream>
using std::endl;
using std::cout;
class Producer:public Thread
{
	public:
		Producer(Buffer&);
		void run();
	private:
		Buffer &_buffer;
};
Producer::Producer(Buffer &buffer)
:_buffer(buffer)
{}
void Producer::run()
{
	srand(time(NULL));
	while(true)
	{
		ElemType new_data=rand()%100;
		cout<<"produce a number: "<<new_data<<endl;
		_buffer.push(new_data);
		sleep(1);
	}
}
#endif
