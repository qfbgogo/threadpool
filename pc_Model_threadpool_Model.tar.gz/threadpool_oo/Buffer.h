 ///
 /// @file    Buffer.h
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-10 19:28:48
 ///
#ifndef __BUFFER_H__
#define __BUFFER_H__
#include "MutexLock.h"
#include "Condition.h"
#include "Task.h"
#include <queue>
typedef Task* ElemType;
class Buffer
{
	public:
		Buffer(int);
		void push(ElemType);
		ElemType pop();
		bool empty();
		bool full();
		void wakeup();
	private:
		int _sz;
		MutexLock _mutex;
		Condition _notFull;
		Condition _notEmpty;
		std::queue<ElemType> _que;
		bool _flag;
};
#endif
