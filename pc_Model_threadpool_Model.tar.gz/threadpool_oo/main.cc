 ///
 /// @file    main.cc
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-11 20:47:22
 ///
#include "Threadpool.h"
#include "Buffer.h"
#include "Task.h"
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include <iostream>
using std::cout;
using std::endl;
class MyTask:public Task
{
	public:
		void execute()
		{
			srand(time(NULL));
			int number=rand()%100;
			cout<<"produce a number: "<<number<<endl;
		}
};
int main()
{
	Task *task=new MyTask;
	Threadpool threadpool(10,4);
	threadpool.start();

	size_t cnt=20;
	while(cnt--)
	{
		threadpool.addTask(task);
	}
	return 0;
}
