 ///
 /// @file    ThreadpoolThread.h
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-11 10:43:56
 ///
#ifndef __THREADPOOLTHREAD_H__
#define __THREADPOOLTHREAD_H__
#include "Thread.h"
#include "Threadpool.h"
#include <iostream>
using std::cout;
using std::endl;
class ThreadpoolThread:public Thread
{
	private:
		Threadpool &_threadpool;
	public:
		ThreadpoolThread(Threadpool &);
		void run();
};
ThreadpoolThread::ThreadpoolThread(Threadpool &threadpool)
:_threadpool(threadpool)
{}
void ThreadpoolThread::run()
{
	_threadpool.threadFunc();		
}
#endif
