 ///
 /// @file    Task.h
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-11 10:37:19
 ///
#ifndef __TASK_H__
#define __TASK_H__
class Task
{
	public:
		virtual void execute()=0;
};
#endif
