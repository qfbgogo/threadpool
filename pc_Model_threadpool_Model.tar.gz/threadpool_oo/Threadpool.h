 ///
 /// @file    Threadpool.h
 /// @author  lisa(1980254245@qq.com)
 /// @date    2017-05-11 10:24:25
 ///
#ifndef __THREADPOOL_H__
#define __THREADPOOL_H__
#include "Thread.h"
#include "Task.h"
#include "Buffer.h"
#include <vector>
using std::vector;
class Threadpool
{
	private:
		vector<Thread *> _threads;
		Buffer _buffer;
		int _threadNum;
		int _buffsize;
		bool _isExit;
	public:
		void addTask(Task *);
		Task *getTask();
		void threadFunc();
		Threadpool(size_t buffsize,size_t threadnum);
		~Threadpool();
		void start();
		void stop();
};
#endif
